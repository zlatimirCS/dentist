(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__1iuj0tl1b8diy._.css","static/chunks/node_modules_next_dist_20wefz_f1k6jn._.js","static/chunks/node_modules_next_dist_1yc9fjw0kn_sg._.js","static/chunks/src_components_1shbobof3h7lr._.js"],
    source: "entry"
});
