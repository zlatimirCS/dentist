:HL["/_next/static/chunks/2hfbse66fz1vb.css","style"]
:HL["/_next/static/media/82450a180bcad83c-s.p.0p-wng2nn8o-p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/edb99fec956915f8-s.p.32sris142tqlb.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
2:[["children",{"s":"__PAGE__","h":49314}]]
1:[["children",{"s":"about","h":49250,"c":"$Q2"}]]
0:{"b":"8GO1x6dv6nwA0SQYYrTpu","t":{"t":{"s":"","h":49234,"c":"$Q1"}}}
