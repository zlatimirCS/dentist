globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/8GO1x6dv6nwA0SQYYrTpu/_buildManifest.js",
    "static/8GO1x6dv6nwA0SQYYrTpu/_ssgManifest.js",
    "static/8GO1x6dv6nwA0SQYYrTpu/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1pcw6gskne7pf.js",
    "static/chunks/3mwm0pfu8c8me.js",
    "static/chunks/3iz8_hoapa1o_.js",
    "static/chunks/2fuxlcqleg9x-.js",
    "static/chunks/turbopack-2u1d16houkiyo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3iz8_hoapa1o_.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3iz8_hoapa1o_.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3iz8_hoapa1o_.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/about/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3iz8_hoapa1o_.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
